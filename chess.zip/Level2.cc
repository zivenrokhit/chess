#include "level2.h"


Level2::Level2(const string &c, Game *g) {
    this->side = c;
    this->game = g;
}


Level2::~Level2() {};

