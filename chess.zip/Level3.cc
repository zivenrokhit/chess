#include "level3.h"


Level3::Level3(const string &c, Game *g) {
    this->side = c;
    this->game = g;
}


Level3::~Level3() {};

