#include "level4.h"


Level4::Level4(const string &c, Game *g) {
    this->side = c;
    this->game = g;
}


Level4::~Level4() {};

